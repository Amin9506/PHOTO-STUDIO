package com.photostudio.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF0D1411)
private val Panel = Color(0xFF18231D)
private val Panel2 = Color(0xFF223128)
private val Mint = Color(0xFFB7E4A8)
private val Muted = Color(0xFFA7B5AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoStudioApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PhotoStudioApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var edited by remember { mutableStateOf<Bitmap?>(null) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableIntStateOf(0) }
    var flip by remember { mutableStateOf(false) }
    var compareOriginal by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }
    var aiPrompt by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        original = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                        brightness = 0f
                        contrast = 1f
                        saturation = 1f
                        rotation = 0
                        flip = false
                        compareOriginal = false
                    } else {
                        Toast.makeText(context, "Не удалось открыть изображение", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Ошибка открытия фото: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(original, brightness, contrast, saturation, rotation, flip) {
        val source = original
        if (source != null) {
            isProcessing = true
            val result = withContext(Dispatchers.Default) {
                renderBitmap(source, brightness, contrast, saturation, rotation, flip)
            }
            edited = result
            isProcessing = false
        } else {
            edited = null
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Mint,
        onPrimary = Color(0xFF142018),
        background = Ink,
        surface = Panel,
        onSurface = Color(0xFFF3F6F0),
        secondary = Muted
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PHOTO STUDIO", fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                            Text("Профессиональная фотостудия", color = Muted, fontSize = 11.sp)
                        }
                    },
                    colors = androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
                        containerColor = Ink,
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Text("✦") },
                        label = { Text("Редактор") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Text("AI") },
                        label = { Text("AI Studio") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Text("▣") },
                        label = { Text("Проекты") }
                    )
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> EditorScreen(
                    modifier = Modifier.padding(padding),
                    original = original,
                    edited = edited,
                    brightness = brightness,
                    contrast = contrast,
                    saturation = saturation,
                    isProcessing = isProcessing,
                    compareOriginal = compareOriginal,
                    onPick = { imagePicker.launch("image/*") },
                    onBrightness = { brightness = it },
                    onContrast = { contrast = it },
                    onSaturation = { saturation = it },
                    onRotate = { rotation = (rotation + 90) % 360 },
                    onFlip = { flip = !flip },
                    onCompare = { compareOriginal = !compareOriginal },
                    onReset = {
                        brightness = 0f; contrast = 1f; saturation = 1f
                        rotation = 0; flip = false; compareOriginal = false
                    },
                    onPreset = { preset ->
                        when (preset) {
                            "Оригинал" -> { brightness = 0f; contrast = 1f; saturation = 1f }
                            "Тёплый" -> { brightness = 0.04f; contrast = 1.08f; saturation = 1.12f }
                            "Яркий" -> { brightness = 0.02f; contrast = 1.18f; saturation = 1.35f }
                            "Моно" -> { brightness = 0f; contrast = 1.12f; saturation = 0f }
                            "Мягкий" -> { brightness = 0.06f; contrast = 0.92f; saturation = 0.88f }
                        }
                    },
                    onSave = {
                        val bitmap = edited
                        if (bitmap != null) {
                            val saved = saveToGallery(context, bitmap)
                            Toast.makeText(
                                context,
                                if (saved != null) "Фото сохранено в Pictures/PhotoStudio" else "Не удалось сохранить фото",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                )
                1 -> AiScreen(prompt = aiPrompt, onPrompt = { aiPrompt = it }, hasPhoto = original != null)
                else -> ProjectsScreen(hasPhoto = original != null, onOpenEditor = { selectedTab = 0 }, onPick = { imagePicker.launch("image/*") })
            }
        }
    }
}

@Composable
private fun EditorScreen(
    modifier: Modifier,
    original: Bitmap?,
    edited: Bitmap?,
    brightness: Float,
    contrast: Float,
    saturation: Float,
    isProcessing: Boolean,
    compareOriginal: Boolean,
    onPick: () -> Unit,
    onBrightness: (Float) -> Unit,
    onContrast: (Float) -> Unit,
    onSaturation: (Float) -> Unit,
    onRotate: () -> Unit,
    onFlip: () -> Unit,
    onCompare: () -> Unit,
    onReset: () -> Unit,
    onPreset: (String) -> Unit,
    onSave: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxSize().background(Ink).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Рабочее пространство", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Редактируй фото без потери оригинала", color = Muted, fontSize = 12.sp)
            }
            OutlinedButton(onClick = onPick) { Text("＋ Фото") }
        }

        Card(
            modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Panel)
        ) {
            Box(
                modifier = Modifier.fillMaxWidth().height(260.dp).padding(10.dp)
                    .background(Color(0xFF0A100D), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                val shown = if (compareOriginal) original else edited
                if (shown != null) {
                    Image(
                        bitmap = shown.asImageBitmap(),
                        contentDescription = "Предпросмотр фотографии",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("▧", fontSize = 42.sp, color = Mint)
                        Spacer(Modifier.height(8.dp))
                        Text("Добавь фотографию", fontWeight = FontWeight.SemiBold)
                        Text("JPG · PNG · WebP", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onPick, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Color(0xFF142018))) {
                            Text("Выбрать из галереи")
                        }
                    }
                }
                if (isProcessing) {
                    Surface(color = Color(0xCC101713), shape = RoundedCornerShape(20.dp), modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                        Text("Обработка…", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 11.sp)
                    }
                }
            }
        }

        if (original != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onCompare, modifier = Modifier.weight(1f)) { Text(if (compareOriginal) "Показать результат" else "Сравнить оригинал") }
                OutlinedButton(onClick = onRotate, modifier = Modifier.weight(1f)) { Text("↻ Поворот") }
                OutlinedButton(onClick = onFlip, modifier = Modifier.weight(1f)) { Text("⇋ Отразить") }
            }

            Text("БЫСТРЫЕ СТИЛИ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Оригинал", "Тёплый", "Яркий", "Моно", "Мягкий").forEach { preset ->
                    OutlinedButton(onClick = { onPreset(preset) }) { Text(preset) }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Adjustment("Яркость", brightness, -0.35f, 0.35f, onBrightness, "%.2f")
                    Adjustment("Контраст", contrast, 0.5f, 1.8f, onContrast, "%.2f")
                    Adjustment("Насыщенность", saturation, 0f, 2f, onSaturation, "%.2f")
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onReset, modifier = Modifier.weight(1f)) { Text("Сбросить") }
                Button(
                    onClick = onSave,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Color(0xFF142018))
                ) { Text("Сохранить фото") }
            }
        } else {
            Text("После загрузки фото появятся инструменты редактирования.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 18.dp))
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun Adjustment(
    title: String,
    value: Float,
    min: Float,
    max: Float,
    onChange: (Float) -> Unit,
    format: String
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(String.format(Locale.US, format, value), color = Mint, fontSize = 12.sp)
    }
    Slider(value = value, onValueChange = onChange, valueRange = min..max)
}

@Composable
private fun AiScreen(prompt: String, onPrompt: (String) -> Unit, hasPhoto: Boolean) {
    Column(
        Modifier.fillMaxSize().background(Ink).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("AI STUDIO", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Text("Творческие инструменты на базе искусственного интеллекта", color = Muted, fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("✦ Умная обработка", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (hasPhoto) "Фотография выбрана. Опиши желаемый результат — например: «замени фон на горный пейзаж на закате, сохрани товар без изменений»."
                    else "Сначала открой вкладку «Редактор» и выбери фотографию.",
                    color = Muted, fontSize = 13.sp
                )
                androidx.compose.material3.OutlinedTextField(
                    value = prompt,
                    onValueChange = onPrompt,
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    label = { Text("Что изменить на фото?") },
                    placeholder = { Text("Например: студийный свет и светлый фон…") }
                )
                Button(
                    onClick = { },
                    enabled = false,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Color(0xFF142018))
                ) { Text("Подключить AI-обработку") }
                Text(
                    "ИИ пока не подключён: для генерации и замены фона нужен защищённый сервер и API выбранной модели. Ключ нельзя безопасно вшивать в APK. Экран и поле запроса подготовлены, но кнопка не имитирует несуществующую обработку.",
                    color = Muted, fontSize = 11.sp, lineHeight = 16.sp
                )
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Что предусмотрено для AI-модуля", fontWeight = FontWeight.Bold)
                Text("• Замена и расширение фона\n• Удаление объектов\n• Генеративное заполнение\n• Улучшение качества и резкости\n• Портретная ретушь\n• Создание рекламных сцен", color = Color(0xFFDCE7DC), fontSize = 13.sp, lineHeight = 21.sp)
            }
        }
    }
}

@Composable
private fun ProjectsScreen(hasPhoto: Boolean, onOpenEditor: () -> Unit, onPick: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Ink).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("МОИ ПРОЕКТЫ", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Text("Рабочее пространство для твоих фотографий.", color = Muted, fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Текущая сессия", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(if (hasPhoto) "Фото загружено в редактор. Продолжи работу или сохрани результат в галерею." else "Пока нет загруженной фотографии.", color = Muted, fontSize = 13.sp)
                Button(onClick = onOpenEditor, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Color(0xFF142018))) {
                    Text(if (hasPhoto) "Вернуться в редактор" else "Открыть редактор")
                }
                OutlinedButton(onClick = onPick) { Text("Выбрать фотографию") }
            }
        }
        Text("Экспортированные изображения сохраняются в галерее Samsung: Pictures / PhotoStudio.", color = Muted, fontSize = 12.sp)
        Text("Следующий этап: локальная библиотека проектов с историей правок и восстановлением сессий.", color = Muted, fontSize = 12.sp)
    }
}

private fun renderBitmap(
    source: Bitmap,
    brightness: Float,
    contrast: Float,
    saturation: Float,
    rotation: Int,
    flip: Boolean
): Bitmap {
    val bc = ColorMatrix(
        floatArrayOf(
            contrast, 0f, 0f, 0f, brightness * 255f + (1f - contrast) * 127.5f,
            0f, contrast, 0f, 0f, brightness * 255f + (1f - contrast) * 127.5f,
            0f, 0f, contrast, 0f, brightness * 255f + (1f - contrast) * 127.5f,
            0f, 0f, 0f, 1f, 0f
        )
    )
    val sat = ColorMatrix().apply { setSaturation(saturation) }
    sat.postConcat(bc)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(sat)
    }
    val adjusted = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    Canvas(adjusted).drawBitmap(source, 0f, 0f, paint)

    if (rotation == 0 && !flip) return adjusted
    val matrix = Matrix().apply {
        postRotate(rotation.toFloat())
        if (flip) postScale(-1f, 1f)
    }
    return Bitmap.createBitmap(adjusted, 0, 0, adjusted.width, adjusted.height, matrix, true)
}

private fun saveToGallery(context: Context, bitmap: Bitmap): Uri? {
    val name = "PhotoStudio_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, name)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PhotoStudio")
        put(MediaStore.Images.Media.IS_PENDING, 1)
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
    return try {
        resolver.openOutputStream(uri)?.use { output ->
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, output)) throw IllegalStateException("JPEG encode failed")
        } ?: throw IllegalStateException("Output stream unavailable")
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        uri
    } catch (e: Exception) {
        resolver.delete(uri, null, null)
        null
    }
}
